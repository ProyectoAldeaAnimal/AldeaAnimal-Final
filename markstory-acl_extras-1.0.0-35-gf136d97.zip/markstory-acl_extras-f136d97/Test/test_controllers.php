<?php

class CommentsController extends Controller {

	public function add() {
	}

	public function index() {
	}

	public function delete() {
	}

	public function _secret_method() {
	}

}

class PostsController extends Controller {

	public function index() {
	}

	public function add() {
	}

	public function edit() {
	}

}

class BigLongNamesController extends Controller {

	public function index() {
	}

	public function view() {
	}

	public function add() {
	}

	public function delete() {
	}

}